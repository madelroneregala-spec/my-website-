# Personal Portfolio — Activity 01: ALL OR NOTHING

A modern, responsive personal portfolio website built with **HTML5 and CSS3 only**. No JavaScript, JavaScript libraries, or frameworks are used.

## Project structure

```text
Personal-Portfolio-Activity-01/
├── index.html
├── about.html
├── gallery.html
├── css/
│   └── style.css
├── images/
│   └── README.txt
└── README.md
```

## Before submitting: personalize your website

Search the project files for `Your Name`, `YOURNAME`, and `your.email@example.com`. Replace them with your own information. Also update:
- The short introduction and personal story.
- Your actual skills and interests.
- The sample portfolio cards with your own projects or class activities.
- The email address in the `mailto:` links.
- The copyright name in each page footer.

The portrait-style artwork and portfolio preview cards are CSS illustrations made for this starter design. They are not photographs or proof of completed client projects.

## Run locally

1. Download or extract the project folder.
2. Open `index.html` in a modern browser.
3. Use the navigation to visit Home, About, and Portfolio.

No build tools or installation are required.

## Publish using GitHub Pages

1. Sign in to GitHub and create a **new public repository** (for example, `personal-portfolio`).
2. Upload the contents of this folder. Make sure `index.html` is in the repository's root directory, not inside an extra nested folder.
3. Open the repository's **Settings**.
4. Select **Pages** from the left menu.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to finish publishing. Your public website address will appear in the Pages section, usually in the form `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.
8. Open the published link and test every navigation link and page.

## HTML/CSS-only compliance

- HTML5 for semantic page structure and navigation.
- CSS3 for layout, responsive styling, hover states, and decorative artwork.
- No `<script>` elements, JavaScript files, inline event handlers, or JavaScript libraries.
- Navigation uses ordinary HTML links.
- Responsive layouts use CSS Grid, Flexbox, and media queries.

## Accessibility and quality checks

- Each page has a unique title and meta description.
- Pages declare a language and responsive viewport.
- Navigation uses semantic `<nav>` landmarks and descriptive link text.
- Keyboard users can navigate links using the browser's normal focus behavior.
- Reduced-motion preferences are respected in CSS.
- Test the site at desktop and mobile widths before submission.

## Credits

Fonts are loaded from Google Fonts (DM Sans and Manrope). An internet connection is needed for those fonts; the site will fall back to the browser's sans-serif fonts if they cannot load.
